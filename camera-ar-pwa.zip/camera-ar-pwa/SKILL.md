---
name: camera-ar-pwa
description: Build and debug web-based camera AR experiences (real rear-camera, GPS, compass) in mobile/PC browsers, including PWA cache-busting and permission handling.
agent_created: true
---

# Camera AR + PWA 调试

## 何时使用

- 用户要求网页调用真实摄像头做 AR 导览、AI 识图、扫码取景等功能。
- 需要同时请求摄像头 (`getUserMedia`)、定位 (`geolocation`) 和方向传感器 (`deviceorientation`)。
- 手机端点击后没有弹出系统权限、摄像头默认使用前置、桌面端点击 AR 无响应、Service Worker 缓存旧代码。

## 核心要点

### 1. 必须使用 HTTPS / localhost

`getUserMedia` 和精确定位在 HTTP（非安全上下文）下会被浏览器直接拒绝，不会弹出权限框。

- 生产环境用 HTTPS。
- 开发环境用 `localhost` 或内网自签名证书。
- 在权限 UI 里检测 `window.isSecureContext`，非安全时提示用户切换到 HTTPS。

### 2. 摄像头约束：强制后置 + 可切换

```js
// 强制后置，失败再降级
var constraints = {
  video: {
    facingMode: { exact: 'environment' },
    width: { ideal: 1280 },
    height: { ideal: 720 }
  },
  audio: false
};
navigator.mediaDevices.getUserMedia(constraints)
  .catch(() => navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false }))
  .catch(() => navigator.mediaDevices.getUserMedia({ video: true, audio: false }));
```

切换摄像头：

- 先 `stream.getTracks().forEach(t => t.stop())` 释放当前流。
- 重新 `getUserMedia` 并传入 `facingMode: { exact: 'user' }` 或 `{ exact: 'environment' }`。
- 在右下角放一个切换按钮，并记录当前 `currentFacingMode`。

### 3. Service Worker 缓存导致旧代码不生效

如果页面缓存了旧版 JS，即使 HTML 更新，浏览器仍可能执行旧的 AR 逻辑。

- JS/CSS/HTML 使用 **网络优先** 策略。
- 每次修改静态资源后，同时更新：
  1. 文件本身的 `<script src="...?v=X">` 查询参数。
  2. `index.html` 中 `sw.js?v=X` 注册参数。
  3. Service Worker 内部的 `CACHE_VERSION` / `CACHE_NAME`。

### 4. 常用调试清单

- [ ] `ar-tour.js` 加载顺序在 `data.js` 之后、调用 `window.ARTour.open` 的脚本之前。
- [ ] `window.ARTour` 暴露 `open / close / isOpen` 方法。
- [ ] CSS 中的权限面板、摄像头画面、底部按钮、结果面板类名与 JS 生成的一致。
- [ ] 使用 Node `node --check js/ar-tour.js` 做语法检查。
- [ ] 桌面端测试使用 `https://localhost:3443` 或 `http://localhost:3000`（localhost 是安全上下文）。
- [ ] iOS 13+ 的方向传感器需要用户手势触发 `DeviceOrientationEvent.requestPermission()`。

## 资源

无外部脚本/模板，本 Skill 为经验清单与代码片段参考。
